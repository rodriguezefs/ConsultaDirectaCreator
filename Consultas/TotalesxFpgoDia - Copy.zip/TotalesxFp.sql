DECLARE @Suc VARCHAR(2) 
DECLARE @Fch VARCHAR(10) 

SET @Suc='AC'
SET @Fch='?Fch'

SELECT DscFpgo +' ['+ MonVmt +']' "Forma de Pago", CtFpgo "Cantidad", TotMovV "Monto"
FROM (
	--FPGO
	SELECT DetVM.TipVmt TipVmt#Enum
	, CASE TipVmt
	   WHEN 10 THEN 'Efectivo'
	   WHEN 30 THEN 'Cheque'
	   WHEN 60 THEN ISNULL(Cpn.NomCpn,'')
	   WHEN 70 THEN ISNULL(Trjp.NomTrjp,'')
	   ELSE '' END DscFpgo
	, DetVM.MonVmt
	, Trjp.TipTrjp TipTrjp#Enum
	, COUNT(*) CtFpgo
	, SUM(CASE WHEN DetVM.NcjUbvOri<>0 THEN -1 ELSE 1 END * DetVM.MntMovD) TotMov
	, SUM(CASE WHEN DetVM.NcjUbvOri<>0 THEN -1 ELSE 1 END * DetVM.MntMovV) TotMovV
	FROM GE_DetVM DetVM
	LEFT JOIN GE_Cpn Cpn
	   ON Cpn.Cpn=DetVM.Cpn
	LEFT JOIN GE_Trjp Trjp
	   ON Trjp.Trjp=DetVM.Trjp
	WHERE IdDoc IN (
	   SELECT EncCFM.IdDoc
	   FROM GE_EncCFM EncCFM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCFM.StDoc=1

	   UNION ALL
	   SELECT EncCDM.IdDoc
	   FROM GE_EncCDM EncCDM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCDM.StDoc=1
	   )
	GROUP BY DetVM.TipVmt, DetVM.Cpn, Cpn.NomCpn, DetVM.Trjp, Trjp.NomTrjp, Trjp.TipTrjp, DetVM.MonVmt

	UNION ALL
	SELECT -1 TipVmt, DetCN.Cnp + '-' + DetCN.DscDet DscFpgo
	, DetCN.MonMov
	, 0 TipTrjp
	, COUNT(*) CtFpgo
	, SUM(CASE WHEN DetCN.TipDoc=23 THEN -1 ELSE 1 END * DetCN.MntMov) MntMov
	, SUM(CASE WHEN DetCN.TipDoc=23 THEN -1 ELSE 1 END * DetCN.MntMov) MntMovV
	FROM GE_DetCN DetCN
	WHERE IdDoc IN (
	   SELECT EncCFM.IdDoc
	   FROM GE_EncCFM EncCFM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCFM.StDoc=1

	   UNION ALL
	   SELECT EncCDM.IdDoc
	   FROM GE_EncCDM EncCDM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCDM.StDoc=1 
	   )
	   AND IdBlk=1
	GROUP BY DetCN.Cnp + '-' + DetCN.DscDet, DetCN.MonMov

	UNION ALL
	SELECT -2 TipVmt
	, CASE OpMbc
	   WHEN 100 THEN 'Depósito'
	   WHEN 504 THEN 'Transferencia'
	   END + ' ' +Mbc.Ctab DscFpgo
	, MBC.MonMbc
	, 0 TipTrjp
	, COUNT(*) CtFpgo
	, SUM(CAST(Z_MntMbcD.VlrACol AS Money)) MntMbc
	, SUM(MntMbc) MntMbcV
	FROM GE_DetMB DetMB
	LEFT JOIN GE_Mbc Mbc
	   ON Mbc.IdMbc=DetMB.IdMbc
	LEFT JOIN GE_VwZItfT Z_MntMbcD
	   ON Z_MntMbcD.NomTbl='GE_DetMB'
	   AND Z_MntMbcD.PkReg=DetMB.IdDoc+'|'+DetMB.IdBlk+'ü'+CAST(DetMB.Sec AS CHAR)
	   AND Z_MntMbcD.NomCol='MntMbcD'

	WHERE IdDoc IN (
	   SELECT EncCFM.IdDoc
	   FROM GE_EncCFM EncCFM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCFM.StDoc=1

	   UNION ALL
	   SELECT EncCDM.IdDoc
	   FROM GE_EncCDM EncCDM
	   WHERE Suc=@Suc
		   AND FchDoc=@Fch
		   AND EncCDM.StDoc=1 
	   )
	  AND IdBlk=1
	  GROUP BY OpMbc, MBC.MonMbc, Mbc.Ctab
) Vw
ORDER BY MonVmt